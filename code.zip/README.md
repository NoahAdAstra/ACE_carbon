# ACE_carbon
ACE project part 2.1. carbon fiber wing pice.
